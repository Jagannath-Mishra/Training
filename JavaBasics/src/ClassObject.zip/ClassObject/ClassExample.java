package ClassObject;

class ClassExample {

	
	public static void main(String[] args) {
		
		
	 Car object = new Car();
	 object.price = 20.00;
	 //System.out.println();
	 
	 System.out.println(object.price);
		
	}
    
	
	
	

	
	
	
}
